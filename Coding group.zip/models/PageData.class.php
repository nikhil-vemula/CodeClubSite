<?php
class PageData
{
	public $title = "";
	public $content = "";
	public $css="";
	public $embeddedStyle="";
}