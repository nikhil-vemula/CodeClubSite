<?php
$dbInfo = "mysql:host=localhost;dbname=wdb";
$dbUser = "root";
$dbPassword = "";
?>