<?php
return "<!DOCTYPE html>
<html>
<head>
<title>$pageData->title</title>
$pageData->css
</head>
<body>
$pageData->content
</body>
</html>";
?>